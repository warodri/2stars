import type { RawBehaviourSignals } from '../models/signal.model';

export function extractFeatures(behaviour: RawBehaviourSignals) {
    const avgDelay = behaviour.typing.avgDelay;
    const variance = behaviour.typing.variance;
    const timeToFirstInput = behaviour.hesitation.timeToFirstInput;
    const sessionDuration = behaviour.hesitation.sessionDuration;
    const avgAcceleration = behaviour.pointer.avgAcceleration;
    const avgSpeed = behaviour.pointer.avgSpeed;

    return {
        typingSpeed: clamp01(1 - normalize(avgDelay, 50, 400)),
        typingConsistency: clamp01(safeRatio(variance, avgDelay)),
        hesitationRatio: clamp01(safeRatio(timeToFirstInput, sessionDuration)),
        pointerStability: clamp01(safeRatio(avgAcceleration, avgSpeed))
    };
}

export function normalize(value: number | null, min: number, max: number) {
    if (!value) {
        return 0.5;
    }

    const v = Math.max(min, Math.min(max, value));
    return (v - min) / (max - min);
}

function safeRatio(value: number | null, base: number | null) {
    if (!value || !base) {
        return 0.5;
    }

    return value / base;
}

function clamp01(value: number) {
    return Math.max(0, Math.min(1, value));
}
