// packages/core/src/client/IdentityClient.ts

import { BehaviourCollector } from '../collectors/behaviour/behaviour.collector';
import type { IdentityClientConfig } from '../models/config.model';
import type { VerificationResponse } from '../models/response.model';
import { collectSignals } from '../services/signal.service';
import { sendToServer } from '../services/transport.service';
import { extractFeatures } from '../utils/features';

export class IdentityClient {
    private behaviourCollector = new BehaviourCollector();

    constructor(private config: IdentityClientConfig) {
        if (!config.clientUserId) {
            throw new Error('IdentityClient requires clientUserId');
        }

        if (!config.action) {
            throw new Error('IdentityClient requires action');
        }

        this.behaviourCollector.start();
    }

    async verify(): Promise<VerificationResponse> {
        const payload = await collectSignals(this.config, this.behaviourCollector);

        const response = await sendToServer(payload, this.config);
        this.behaviourCollector.reset();

        return response;
    }

    getBehaviourDebug() {
        const behaviour = this.behaviourCollector.getProfile();

        return {
            ...behaviour,
            features: extractFeatures(behaviour)
        };
    }

    destroy() {
        this.behaviourCollector.stop();
    }
}
