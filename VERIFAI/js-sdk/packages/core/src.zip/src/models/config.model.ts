export type IdentityClientConfig = {
    apiKey: string;
    endpoint: string;
    clientUserId: string;
    action: string;
};
