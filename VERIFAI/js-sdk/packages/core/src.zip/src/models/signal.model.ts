export type SdkPlatform = 'js';

export type BrowserSignals = {
    device: {
        userAgent: string;
        platform: string;
        language: string;
    };
    browser: {
        screen: {
            width: number;
            height: number;
            pixelRatio: number;
        };
        timezone: string;
    };
};

export type RawBehaviourSignals = {
    typing: {
        keyCount: number;
        inputCount: number;
        pasteCount: number;
        avgDelay: number | null;
        variance: number | null;
        correctionRate: number;
    };
    pointer: {
        movementCount: number;
        avgSpeed: number | null;
        avgAcceleration: number | null;
        clickCount: number;
        avgClickInterval: number | null;
        tapCount: number;
        avgTapInterval: number | null;
    };
    hesitation: {
        timeToFirstInput: number | null;
        sessionDuration: number;
    };
    focus: {
        focusCount: number;
        transitionCount: number;
        tabTransitions: number;
        pointerTransitions: number;
        touchTransitions: number;
        keyboardTransitions: number;
        unknownTransitions: number;
        avgFocusDelay: number | null;
        sequence: Array<{
            from: string | null;
            to: string;
            method: 'tab' | 'pointer' | 'touch' | 'keyboard' | 'unknown';
            delay: number | null;
        }>;
    };
    diagnostics: {
        isStarted: boolean;
        startedAt: number;
        capturedEventCount: number;
    };
};

export type BehaviourSignals = RawBehaviourSignals & {
    features: {
        typingSpeed: number;
        typingConsistency: number;
        hesitationRatio: number;
        pointerStability: number;
    };
};

export type CollectedSignals = BrowserSignals & {
    behaviour: BehaviourSignals;
};

export type VerificationPayload = {
    clientUserId: string;
    action: string;
    platform: SdkPlatform;
    deviceId: string;
    sessionId: string;
    timestamp: number;
    signals: CollectedSignals;
};
