// packages/core/src/services/signal.service.ts

import type { BehaviourCollector } from '../collectors/behaviour/behaviour.collector';
import { BrowserCollector } from '../collectors/browser/browser.collector';
import type { IdentityClientConfig } from '../models/config.model';
import type { VerificationPayload } from '../models/signal.model';
import { extractFeatures } from '../utils/features';
import { createSessionId, getOrCreateDeviceId } from './session.service';

export async function collectSignals(
    config: IdentityClientConfig,
    behaviourCollector: BehaviourCollector
): Promise<VerificationPayload> {
    const collector = new BrowserCollector();

    const browserSignals = await collector.collect();
    const deviceId = await getOrCreateDeviceId(browserSignals);

    const behaviour = behaviourCollector.getProfile();

    return {
        clientUserId: config.clientUserId,
        action: config.action,
        platform: 'js',
        deviceId,
        sessionId: createSessionId(),
        timestamp: Date.now(),
        signals: {
            ...browserSignals,
            behaviour: {
                ...behaviour,
                features: extractFeatures(behaviour)
            }
        }
    };
}
